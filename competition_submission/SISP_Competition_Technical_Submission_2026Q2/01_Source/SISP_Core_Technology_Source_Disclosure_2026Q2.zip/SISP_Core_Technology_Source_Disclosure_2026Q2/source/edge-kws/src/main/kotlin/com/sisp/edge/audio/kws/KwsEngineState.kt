package com.sisp.edge.audio.kws

enum class KwsEngineState {
    IDLE,
    READY,
    RUNNING,
    ERROR
}
