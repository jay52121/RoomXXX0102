package com.sisp.edge.audio.audio

data class AudioFrame(
    val pcm: ShortArray,
    val sampleRate: Int,
    val timestampMs: Long,
    val captureMs: Long
)
