package com.sisp.edge.audio.audio

enum class AudioSourceState {
    IDLE,
    RUNNING,
    ERROR
}
