package com.sisp.edge.audio.kws

data class KwsHit(
    val keywordRaw: String,
    val timestampMs: Long,
    val score: Float?
)
