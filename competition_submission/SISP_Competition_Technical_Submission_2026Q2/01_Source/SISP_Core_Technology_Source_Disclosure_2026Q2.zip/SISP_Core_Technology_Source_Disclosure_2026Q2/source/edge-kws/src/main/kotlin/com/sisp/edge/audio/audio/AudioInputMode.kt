package com.sisp.edge.audio.audio

enum class AudioInputMode {
    PLAYBACK,
    MICROPHONE
}
