package com.sisp.edge.fallback.spatial.tracking

/**
 * Runtime descriptor supplied by the host or service-discovery layer.
 * No endpoint, credential or terminal identity is embedded in the algorithm module.
 */
data class TrackerEndpointConfig(
    val endpoint: String,
    val terminalId: String,
    val timeoutMs: Long = 200L
) {
    init {
        require(endpoint.isNotBlank()) { "endpoint must be provided at runtime" }
        require(terminalId.isNotBlank()) { "terminalId must be provided at runtime" }
        require(timeoutMs > 0L) { "timeoutMs must be positive" }
    }
}

data class TrackServiceOutput(
    val trackId: Int,
    val xyxy: FloatArray,
    val confidence: Float,
    val classId: Int = 0
)

data class TrackServiceResponse(
    val frameId: Long,
    val serviceLatencyMs: Double,
    val tracks: List<TrackServiceOutput>
)

/**
 * Outbound port for the tracking service.
 *
 * The production adapter is intentionally excluded from this limited disclosure.
 * A host implementation may use local IPC, HTTP, gRPC or an embedded engine while
 * preserving the same orchestration and fallback semantics.
 */
interface TrackerServicePort {
    val endpointConfig: TrackerEndpointConfig

    fun submitFrame(
        frameId: Long,
        detections: List<TrackDetection>,
        frameWidth: Int,
        frameHeight: Int,
        callback: (TrackServiceResponse?) -> Unit
    )

    fun reset(callback: (Boolean) -> Unit)

    fun checkHealth(callback: (Boolean) -> Unit)
}
