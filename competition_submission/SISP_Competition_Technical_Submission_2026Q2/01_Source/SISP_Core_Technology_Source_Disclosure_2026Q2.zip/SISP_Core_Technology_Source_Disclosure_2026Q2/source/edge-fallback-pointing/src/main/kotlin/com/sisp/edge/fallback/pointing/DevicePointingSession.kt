package com.sisp.edge.fallback.pointing

import android.graphics.PointF

/**
 * Thin orchestration layer for one event-triggered pointing window.
 * Geometry and decision policy remain isolated in scorer and window judge.
 */
class DevicePointingSession(
    private val config: DevicePointingScoringConfig = DevicePointingScoringConfig(),
    private val scorer: DevicePointingScorer = DevicePointingScorer(config),
    private val judge: DevicePointingWindowJudge = DevicePointingWindowJudge(config)
) {
    private var startedAtMs: Long? = null
    private var preparedTargets: List<DevicePreparedTarget> = emptyList()
    private val frames = mutableListOf<DeviceFrameEvaluation>()

    fun begin(
        targets: List<DevicePointingTarget>,
        imageWidth: Int,
        imageHeight: Int,
        timestampMs: Long
    ) {
        preparedTargets = scorer.prepareTargets(targets, imageWidth, imageHeight)
        frames.clear()
        startedAtMs = timestampMs
    }

    fun submit(
        timestampMs: Long,
        rayOrigin: PointF,
        rayDirection: PointF,
        frameQuality: Float
    ): DeviceFrameEvaluation? {
        if (startedAtMs == null || preparedTargets.isEmpty()) return null
        return scorer.buildFrameEvaluation(
            timestampMs = timestampMs,
            rayOrigin = rayOrigin,
            rayDirection = rayDirection,
            rayConfidence = frameQuality.coerceIn(0f, 1f),
            targets = preparedTargets
        ).also(frames::add)
    }

    fun isWindowComplete(timestampMs: Long): Boolean {
        val start = startedAtMs ?: return false
        return timestampMs - start >= config.timeoutMs
    }

    fun finish(): DeviceWindowResult {
        return judge.judge(preparedTargets, frames.toList())
    }

    fun reset() {
        startedAtMs = null
        preparedTargets = emptyList()
        frames.clear()
    }
}
