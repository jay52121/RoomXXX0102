package com.sisp.shared.contracts

/** Confidence threshold shared by pose quality and tracking integrity checks. */
const val POSE_HIGH_CONFIDENCE_THRESHOLD = 0.70f

data class Keypoint(
    val x: Float,
    val y: Float,
    val confidence: Float
) {
    val conf: Float
        get() = confidence
}
