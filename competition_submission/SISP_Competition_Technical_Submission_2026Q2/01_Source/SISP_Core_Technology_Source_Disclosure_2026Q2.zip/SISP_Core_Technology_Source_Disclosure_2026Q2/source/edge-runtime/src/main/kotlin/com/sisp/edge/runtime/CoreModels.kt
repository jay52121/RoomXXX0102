package com.sisp.edge.runtime

enum class CoreCapability {
    CONFIGURATION_AUTHORITY,
    MULTI_CAMERA_TRACKING,
    SPATIAL_STATE,
    MULTIMODAL_FUSION,
    DEVICE_POINTING,
    DEVICE_CONTROL,
    POLICY_DISTRIBUTION,
    TELEMETRY
}

enum class EdgeCapability {
    AUDIO_KWS,
    SINGLE_CAMERA_TRACKING,
    SHORT_WINDOW_POINTING,
    CACHED_SPATIAL_CONFIGURATION
}

enum class ExecutionMode {
    CORE_PRIMARY,
    EDGE_CONTINUITY
}

enum class RuntimePhase {
    IDLE,
    DISCOVERING,
    CONNECTING,
    CORE_ACTIVE,
    EDGE_DEGRADED,
    RECOVERING,
    STOPPED
}

enum class DecisionAuthority {
    SISP_CORE,
    EDGE_PROVISIONAL
}

enum class ObservationKind {
    PERSON_TRACKS,
    HAND_RAY,
    AUDIO_COMMAND,
    DEVICE_WINDOW,
    SPATIAL_EVENT
}

enum class DecisionKind {
    TRACK_ASSIGNMENT,
    DEVICE_TARGET,
    PRESENCE_UPDATE,
    DEVICE_ACTION,
    NO_DECISION
}

data class TerminalDescriptor(
    val terminalId: String,
    val platform: String,
    val clientVersion: String
)

/** Logical endpoint returned by service discovery; transport coordinates remain adapter-private. */
data class CoreEndpointDescriptor(
    val endpointId: String,
    val displayName: String,
    val protocolVersion: String
)

data class CoreSessionDescriptor(
    val sessionId: String,
    val coreVersion: String,
    val configurationVersion: Long,
    val capabilities: Set<CoreCapability>
)

data class ConfigurationSnapshot(
    val version: Long,
    val generatedAtMs: Long,
    val payload: Map<String, String>
)

data class ObservationEnvelope(
    val eventId: String,
    val timestampMs: Long,
    val kind: ObservationKind,
    val payload: Map<String, String>,
    val configurationVersion: Long? = null
)

data class DecisionEnvelope(
    val decisionId: String,
    val eventId: String,
    val timestampMs: Long,
    val kind: DecisionKind,
    val authority: DecisionAuthority,
    val confidence: Float,
    val payload: Map<String, String>
)

data class JournalEntry(
    val sequence: Long,
    val observation: ObservationEnvelope,
    val provisionalDecision: DecisionEnvelope?,
    val configurationVersion: Long?,
    val recordedAtMs: Long
)

data class ReconciliationResult(
    val acknowledgedThroughSequence: Long,
    val authoritativeConfiguration: ConfigurationSnapshot,
    val authoritativeDecisions: List<DecisionEnvelope>
)

data class RuntimeSnapshot(
    val phase: RuntimePhase,
    val mode: ExecutionMode,
    val coreCapabilities: Set<CoreCapability>,
    val edgeCapabilities: Set<EdgeCapability>,
    val configurationVersion: Long?,
    val pendingJournalEntries: Int,
    val lastTransitionReason: String
)
