package com.sisp.edge.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SispRuntimeCoordinatorTest {
    private val nowMs = 10_000L
    private val terminal = TerminalDescriptor("terminal-demo", "Android", "1.0")
    private val configuration = ConfigurationSnapshot(
        version = 7L,
        generatedAtMs = nowMs,
        payload = mapOf("roomGraph" to "cached")
    )

    @Test
    fun `Core 可用时进入权威执行模式`() {
        val core = FakeCorePort(available = true, configuration = configuration)
        val coordinator = coordinator(core)

        coordinator.start(terminal)

        assertEquals(RuntimePhase.CORE_ACTIVE, coordinator.snapshot().phase)
        assertEquals(ExecutionMode.CORE_PRIMARY, coordinator.snapshot().mode)
        assertEquals(0, coordinator.snapshot().pendingJournalEntries)
    }

    @Test
    fun `Core 不可用时执行本地冗余并记录待同步事件`() {
        val core = FakeCorePort(available = false, configuration = configuration)
        val coordinator = coordinator(core)
        var decision: DecisionEnvelope? = null

        coordinator.start(terminal)
        coordinator.submit(observation()) { decision = it }

        assertEquals(RuntimePhase.EDGE_DEGRADED, coordinator.snapshot().phase)
        assertEquals(ExecutionMode.EDGE_CONTINUITY, coordinator.snapshot().mode)
        assertEquals(DecisionAuthority.EDGE_PROVISIONAL, decision?.authority)
        assertEquals(1, coordinator.snapshot().pendingJournalEntries)
    }

    @Test
    fun `Core 恢复后完成日志补传和权威状态对账`() {
        val core = FakeCorePort(available = false, configuration = configuration)
        val coordinator = coordinator(core)

        coordinator.start(terminal)
        coordinator.submit(observation()) {}
        core.available = true
        coordinator.attemptRecovery()

        assertEquals(RuntimePhase.CORE_ACTIVE, coordinator.snapshot().phase)
        assertEquals(ExecutionMode.CORE_PRIMARY, coordinator.snapshot().mode)
        assertEquals(0, coordinator.snapshot().pendingJournalEntries)
        assertTrue(core.reconcileCalled)
    }

    private fun coordinator(core: FakeCorePort): SispRuntimeCoordinator {
        return SispRuntimeCoordinator(
            corePort = core,
            edgeRuntime = FakeEdgeRuntime(),
            initialConfiguration = configuration,
            clockMs = { nowMs }
        )
    }

    private fun observation() = ObservationEnvelope(
        eventId = "event-1",
        timestampMs = nowMs,
        kind = ObservationKind.DEVICE_WINDOW,
        payload = mapOf("ray" to "normalized")
    )

    private class FakeEdgeRuntime : EdgeContinuityRuntime {
        override val capabilities = setOf(
            EdgeCapability.AUDIO_KWS,
            EdgeCapability.SINGLE_CAMERA_TRACKING,
            EdgeCapability.SHORT_WINDOW_POINTING,
            EdgeCapability.CACHED_SPATIAL_CONFIGURATION
        )

        override fun applyConfiguration(snapshot: ConfigurationSnapshot) = Unit

        override fun evaluate(observation: ObservationEnvelope): DecisionEnvelope {
            return DecisionEnvelope(
                decisionId = "edge-decision",
                eventId = observation.eventId,
                timestampMs = observation.timestampMs,
                kind = DecisionKind.DEVICE_TARGET,
                authority = DecisionAuthority.EDGE_PROVISIONAL,
                confidence = 0.72f,
                payload = mapOf("deviceId" to "cached-device")
            )
        }

        override fun reset() = Unit
    }

    private class FakeCorePort(
        var available: Boolean,
        private val configuration: ConfigurationSnapshot
    ) : SispCorePort {
        var reconcileCalled = false

        private val endpoint = CoreEndpointDescriptor("local-core", "SISP Core", "1")
        private val session = CoreSessionDescriptor(
            sessionId = "session-1",
            coreVersion = "2026.2",
            configurationVersion = configuration.version,
            capabilities = CoreCapability.entries.toSet()
        )

        override fun discover(
            terminal: TerminalDescriptor,
            callback: (Result<CoreEndpointDescriptor>) -> Unit
        ) {
            callback(if (available) Result.success(endpoint) else Result.failure(IllegalStateException("offline")))
        }

        override fun openSession(
            endpoint: CoreEndpointDescriptor,
            terminal: TerminalDescriptor,
            callback: (Result<CoreSessionDescriptor>) -> Unit
        ) {
            callback(if (available) Result.success(session) else Result.failure(IllegalStateException("offline")))
        }

        override fun fetchConfiguration(
            session: CoreSessionDescriptor,
            callback: (Result<ConfigurationSnapshot>) -> Unit
        ) {
            callback(Result.success(configuration))
        }

        override fun evaluate(
            session: CoreSessionDescriptor,
            observation: ObservationEnvelope,
            callback: (Result<DecisionEnvelope>) -> Unit
        ) {
            callback(
                Result.success(
                    DecisionEnvelope(
                        decisionId = "core-decision",
                        eventId = observation.eventId,
                        timestampMs = observation.timestampMs,
                        kind = DecisionKind.DEVICE_TARGET,
                        authority = DecisionAuthority.SISP_CORE,
                        confidence = 0.96f,
                        payload = mapOf("deviceId" to "authoritative-device")
                    )
                )
            )
        }

        override fun reconcile(
            session: CoreSessionDescriptor,
            journal: List<JournalEntry>,
            callback: (Result<ReconciliationResult>) -> Unit
        ) {
            reconcileCalled = true
            callback(
                Result.success(
                    ReconciliationResult(
                        acknowledgedThroughSequence = journal.maxOf { it.sequence },
                        authoritativeConfiguration = configuration,
                        authoritativeDecisions = emptyList()
                    )
                )
            )
        }

        override fun closeSession(session: CoreSessionDescriptor) = Unit
    }
}
