package com.sisp.edge.runtime

interface SyncJournal {
    fun append(
        observation: ObservationEnvelope,
        provisionalDecision: DecisionEnvelope?,
        configurationVersion: Long?,
        recordedAtMs: Long
    ): JournalEntry

    fun pending(): List<JournalEntry>

    fun acknowledgeThrough(sequence: Long)

    fun clear()
}

class InMemorySyncJournal(
    private val capacity: Int
) : SyncJournal {
    private val entries = ArrayDeque<JournalEntry>()
    private var nextSequence = 1L

    init {
        require(capacity > 0) { "capacity must be positive" }
    }

    @Synchronized
    override fun append(
        observation: ObservationEnvelope,
        provisionalDecision: DecisionEnvelope?,
        configurationVersion: Long?,
        recordedAtMs: Long
    ): JournalEntry {
        while (entries.size >= capacity) entries.removeFirst()
        return JournalEntry(
            sequence = nextSequence++,
            observation = observation,
            provisionalDecision = provisionalDecision,
            configurationVersion = configurationVersion,
            recordedAtMs = recordedAtMs
        ).also(entries::addLast)
    }

    @Synchronized
    override fun pending(): List<JournalEntry> = entries.toList()

    @Synchronized
    override fun acknowledgeThrough(sequence: Long) {
        while (entries.firstOrNull()?.sequence?.let { it <= sequence } == true) {
            entries.removeFirst()
        }
    }

    @Synchronized
    override fun clear() {
        entries.clear()
    }
}
