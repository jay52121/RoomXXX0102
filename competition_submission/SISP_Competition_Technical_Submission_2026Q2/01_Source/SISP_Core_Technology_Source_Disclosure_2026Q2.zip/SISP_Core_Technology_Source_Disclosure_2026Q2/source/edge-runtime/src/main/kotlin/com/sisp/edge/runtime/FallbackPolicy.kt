package com.sisp.edge.runtime

data class FallbackPolicy(
    val allowedCapabilities: Set<EdgeCapability> = setOf(
        EdgeCapability.AUDIO_KWS,
        EdgeCapability.SINGLE_CAMERA_TRACKING,
        EdgeCapability.SHORT_WINDOW_POINTING,
        EdgeCapability.CACHED_SPATIAL_CONFIGURATION
    ),
    val maxJournalEntries: Int = 256,
    val maxCachedConfigurationAgeMs: Long = 24L * 60L * 60L * 1000L
) {
    init {
        require(maxJournalEntries > 0) { "maxJournalEntries must be positive" }
        require(maxCachedConfigurationAgeMs > 0L) { "maxCachedConfigurationAgeMs must be positive" }
    }

    fun supports(kind: ObservationKind): Boolean {
        return when (kind) {
            ObservationKind.AUDIO_COMMAND -> EdgeCapability.AUDIO_KWS in allowedCapabilities
            ObservationKind.PERSON_TRACKS -> EdgeCapability.SINGLE_CAMERA_TRACKING in allowedCapabilities
            ObservationKind.HAND_RAY,
            ObservationKind.DEVICE_WINDOW -> EdgeCapability.SHORT_WINDOW_POINTING in allowedCapabilities
            ObservationKind.SPATIAL_EVENT -> EdgeCapability.CACHED_SPATIAL_CONFIGURATION in allowedCapabilities
        }
    }

    fun isConfigurationUsable(snapshot: ConfigurationSnapshot?, nowMs: Long): Boolean {
        if (snapshot == null) return false
        return nowMs - snapshot.generatedAtMs <= maxCachedConfigurationAgeMs
    }
}
