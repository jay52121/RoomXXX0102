package com.sisp.edge.runtime

/**
 * Core-facing port implemented by the undisclosed infrastructure adapter.
 * Discovery, authentication, encryption, transport and serialization are intentionally omitted.
 */
interface SispCorePort {
    fun discover(
        terminal: TerminalDescriptor,
        callback: (Result<CoreEndpointDescriptor>) -> Unit
    )

    fun openSession(
        endpoint: CoreEndpointDescriptor,
        terminal: TerminalDescriptor,
        callback: (Result<CoreSessionDescriptor>) -> Unit
    )

    fun fetchConfiguration(
        session: CoreSessionDescriptor,
        callback: (Result<ConfigurationSnapshot>) -> Unit
    )

    fun evaluate(
        session: CoreSessionDescriptor,
        observation: ObservationEnvelope,
        callback: (Result<DecisionEnvelope>) -> Unit
    )

    fun reconcile(
        session: CoreSessionDescriptor,
        journal: List<JournalEntry>,
        callback: (Result<ReconciliationResult>) -> Unit
    )

    fun closeSession(session: CoreSessionDescriptor)
}

/** Restricted on-device capability used only while SISP Core is unavailable. */
interface EdgeContinuityRuntime {
    val capabilities: Set<EdgeCapability>

    fun applyConfiguration(snapshot: ConfigurationSnapshot)

    fun evaluate(observation: ObservationEnvelope): DecisionEnvelope?

    fun reset()
}
