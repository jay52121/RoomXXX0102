package com.sisp.edge.runtime

/**
 * Coordinates Core-first execution, edge degradation and authoritative recovery.
 * It contains no transport implementation and no product-specific algorithm.
 */
class SispRuntimeCoordinator(
    private val corePort: SispCorePort,
    private val edgeRuntime: EdgeContinuityRuntime,
    private val policy: FallbackPolicy = FallbackPolicy(),
    private val journal: SyncJournal = InMemorySyncJournal(policy.maxJournalEntries),
    initialConfiguration: ConfigurationSnapshot? = null,
    private val clockMs: () -> Long = System::currentTimeMillis,
    private val listener: (RuntimeSnapshot) -> Unit = {}
) {
    private val lock = Any()
    private var terminal: TerminalDescriptor? = null
    private var endpoint: CoreEndpointDescriptor? = null
    private var session: CoreSessionDescriptor? = null
    private var configuration: ConfigurationSnapshot? = initialConfiguration
    private var phase = RuntimePhase.IDLE
    private var transitionReason = "created"

    init {
        initialConfiguration?.let(edgeRuntime::applyConfiguration)
    }

    fun start(terminal: TerminalDescriptor) {
        synchronized(lock) {
            this.terminal = terminal
            this.endpoint = null
            this.session = null
        }
        transition(RuntimePhase.DISCOVERING, "runtime-started")
        discoverAndConnect(recovery = false)
    }

    fun submit(
        observation: ObservationEnvelope,
        callback: (DecisionEnvelope?) -> Unit
    ) {
        val activeSession = synchronized(lock) {
            if (phase == RuntimePhase.CORE_ACTIVE) session else null
        }
        if (activeSession == null) {
            evaluateAtEdge(observation, callback)
            return
        }

        corePort.evaluate(activeSession, observation) { result ->
            result.fold(
                onSuccess = callback,
                onFailure = {
                    enterEdgeContinuity("core-evaluation-failed")
                    evaluateAtEdge(observation, callback)
                }
            )
        }
    }

    fun attemptRecovery() {
        val canRecover = synchronized(lock) {
            phase == RuntimePhase.EDGE_DEGRADED && terminal != null
        }
        if (!canRecover) return
        transition(RuntimePhase.RECOVERING, "recovery-requested")
        discoverAndConnect(recovery = true)
    }

    fun stop() {
        val activeSession = synchronized(lock) {
            session.also {
                session = null
                endpoint = null
            }
        }
        activeSession?.let(corePort::closeSession)
        edgeRuntime.reset()
        transition(RuntimePhase.STOPPED, "runtime-stopped")
    }

    fun snapshot(): RuntimeSnapshot = synchronized(lock) { buildSnapshot() }

    private fun discoverAndConnect(recovery: Boolean) {
        val activeTerminal = synchronized(lock) { terminal } ?: return
        corePort.discover(activeTerminal) { discovery ->
            discovery.fold(
                onSuccess = { discovered -> openCoreSession(discovered, activeTerminal, recovery) },
                onFailure = { enterEdgeContinuity("core-discovery-failed") }
            )
        }
    }

    private fun openCoreSession(
        discovered: CoreEndpointDescriptor,
        activeTerminal: TerminalDescriptor,
        recovery: Boolean
    ) {
        synchronized(lock) { endpoint = discovered }
        if (!recovery) transition(RuntimePhase.CONNECTING, "core-discovered")
        corePort.openSession(discovered, activeTerminal) { opened ->
            opened.fold(
                onSuccess = { activeSession ->
                    synchronized(lock) { session = activeSession }
                    fetchConfigurationAndActivate(activeSession, recovery)
                },
                onFailure = { enterEdgeContinuity("core-session-failed") }
            )
        }
    }

    private fun fetchConfigurationAndActivate(
        activeSession: CoreSessionDescriptor,
        recovery: Boolean
    ) {
        corePort.fetchConfiguration(activeSession) { fetched ->
            fetched.fold(
                onSuccess = { snapshot ->
                    synchronized(lock) { configuration = snapshot }
                    edgeRuntime.applyConfiguration(snapshot)
                    if (recovery) reconcile(activeSession) else activateCore("core-session-active")
                },
                onFailure = { enterEdgeContinuity("configuration-fetch-failed") }
            )
        }
    }

    private fun reconcile(activeSession: CoreSessionDescriptor) {
        val pending = journal.pending()
        if (pending.isEmpty()) {
            activateCore("recovered-without-pending-events")
            return
        }
        corePort.reconcile(activeSession, pending) { reconciled ->
            reconciled.fold(
                onSuccess = { result ->
                    journal.acknowledgeThrough(result.acknowledgedThroughSequence)
                    synchronized(lock) { configuration = result.authoritativeConfiguration }
                    edgeRuntime.applyConfiguration(result.authoritativeConfiguration)
                    activateCore("reconciliation-complete")
                },
                onFailure = { enterEdgeContinuity("reconciliation-failed") }
            )
        }
    }

    private fun evaluateAtEdge(
        observation: ObservationEnvelope,
        callback: (DecisionEnvelope?) -> Unit
    ) {
        val currentConfig = synchronized(lock) { configuration }
        val canEvaluate = policy.supports(observation.kind) &&
            policy.isConfigurationUsable(currentConfig, clockMs()) &&
            edgeRuntime.capabilities.any { it in policy.allowedCapabilities }
        val localDecision = if (canEvaluate) edgeRuntime.evaluate(observation) else null
        val provisional = localDecision?.copy(authority = DecisionAuthority.EDGE_PROVISIONAL)
        journal.append(
            observation = observation,
            provisionalDecision = provisional,
            configurationVersion = currentConfig?.version,
            recordedAtMs = clockMs()
        )
        publishSnapshot()
        callback(provisional)
    }

    private fun activateCore(reason: String) {
        transition(RuntimePhase.CORE_ACTIVE, reason)
    }

    private fun enterEdgeContinuity(reason: String) {
        val activeSession = synchronized(lock) {
            session.also { session = null }
        }
        activeSession?.let(corePort::closeSession)
        transition(RuntimePhase.EDGE_DEGRADED, reason)
    }

    private fun transition(next: RuntimePhase, reason: String) {
        val snapshot = synchronized(lock) {
            phase = next
            transitionReason = reason
            buildSnapshot()
        }
        listener(snapshot)
    }

    private fun publishSnapshot() {
        listener(snapshot())
    }

    private fun buildSnapshot(): RuntimeSnapshot {
        val mode = if (phase == RuntimePhase.CORE_ACTIVE) {
            ExecutionMode.CORE_PRIMARY
        } else {
            ExecutionMode.EDGE_CONTINUITY
        }
        return RuntimeSnapshot(
            phase = phase,
            mode = mode,
            coreCapabilities = session?.capabilities.orEmpty(),
            edgeCapabilities = edgeRuntime.capabilities,
            configurationVersion = configuration?.version,
            pendingJournalEntries = journal.pending().size,
            lastTransitionReason = transitionReason
        )
    }
}
