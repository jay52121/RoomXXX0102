pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "sisp-edge-continuity-disclosure"
include(":edge-runtime")
project(":edge-runtime").projectDir = file("source/edge-runtime")
