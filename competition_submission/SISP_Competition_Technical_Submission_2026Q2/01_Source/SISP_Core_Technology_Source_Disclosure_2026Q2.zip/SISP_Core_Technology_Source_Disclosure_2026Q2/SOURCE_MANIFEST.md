# Source Manifest

本清单用于核对有限披露包内的源码范围。哈希算法为 SHA-256。

## 模块统计

| 模块 | Kotlin 文件 | 代码行 |
|---|---:|---:|
| `edge-fallback-pointing` | 9 | 981 |
| `edge-fallback-spatial` | 7 | 1499 |
| `edge-kws` | 21 | 1436 |
| `edge-runtime` | 6 | 645 |
| `shared-contracts` | 1 | 13 |
| **合计** | **44** | **4574** |

## 源码文件

| 路径 | 行数 | SHA-256 |
|---|---:|---|
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingDebugModels.kt` | 26 | `8228e2a019241acf4493eedf34446bcf8dbd0b83c655e1e6b4978b1b093483ee` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingGeometry.kt` | 169 | `a7a7e70d3037fc94059cd9bea9d06ba7448c9950302a4cba6a1a423940a91212` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingModels.kt` | 70 | `8107c050f31d80516c29e168e4cbc84bc50452dbd7abc5a3a513fc82dbffc9db` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingScorer.kt` | 252 | `b8af569f897504605e20e1bb1c20cca177df3173bba05516c9e123aad1085199` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingScoringConfig.kt` | 38 | `f8467cbee860d8aac3ef9507b7db5ba82627216b22d92780201c00c59eae584f` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingSession.kt` | 59 | `ca5363a341d4d6206c9b1e3cbf4def1d1e8e3d5b1d56ca07c599a8a217044663` |
| `source/edge-fallback-pointing/src/main/kotlin/com/sisp/edge/fallback/pointing/DevicePointingWindowJudge.kt` | 168 | `3394129bea39193a1a1ffc1526911a38a96b908337df21ba0df177d42a239f1f` |
| `source/edge-fallback-pointing/src/test/kotlin/com/sisp/edge/fallback/pointing/DevicePointingScorerTest.kt` | 79 | `fe1a37c1be042cf815dba6fb04c4e80ac31696eeda68ff21cb914a33b09b32a3` |
| `source/edge-fallback-pointing/src/test/kotlin/com/sisp/edge/fallback/pointing/DevicePointingWindowJudgeTest.kt` | 120 | `58eb794b669c661b770147defc688b3bdefbb06678b1332bc2100fcc9f227343` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/presence/PresenceAlgorithmEngine.kt` | 37 | `6322938f0dea87d1fbcdd9e073a0b2af5da8a275cbbcba1a7ad718b56b8ca27e` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/presence/PresenceGeometry.kt` | 100 | `7468696504f76587f87517104c3f6ee2bf1eaf817dcf897f54d3f08deae83fc5` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/presence/RoomPresenceChangeLogger.kt` | 55 | `423f4e9be18e685519e0ff62df23f0c72ce11d267804f520d18fca79b1aeab11` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/presence/RoomTransitionEstimator.kt` | 620 | `e3bd5bffa2b14ac1e9590d7a98e7010b33cc6a9d0ce52d61741957f0e1b54d22` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/tracking/ResilientTrackEngine.kt` | 600 | `2782dbba8d407b3af986c8fbd63bdf5e0f3e9da4b2795512e09fc98c8ac677b9` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/tracking/TrackerEngine.kt` | 34 | `f129357fffa014e2c3e2ac94ad39377ed46c4d752cfcd9d548ff9fee30f535fa` |
| `source/edge-fallback-spatial/src/main/kotlin/com/sisp/edge/fallback/spatial/tracking/TrackerServicePort.kt` | 53 | `50e73d4c6a1b0ac418cd40feee7bca8015a177569fee60efe35c280455d0e5f1` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/Command.kt` | 11 | `303ac37a37c58486bbebe023fd6d1c4dfc2add433942b795092cf63e80451abb` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/CommandEvent.kt` | 15 | `5068641040fc24f3c8255ba82fdfbdc968bf37610576b92166826fd7f4fae3f0` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/CommandMapper.kt` | 11 | `a5652af1118b3752a5f43f7400bf6ea0a3e09d32b67e01c8899c1d0728ae007d` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/KwsConfig.kt` | 35 | `f1bd2e53fa0bac9d22a60acdcbfd32221bbb19227ef6bbac1c4168c5ed7fa4df` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/KwsController.kt` | 28 | `9a8392a687aa494ccbb2e65f59baff4880ef237c2fe1f97799fd8d61fc84e532` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/KwsControllerImpl.kt` | 551 | `7419ae96821d4d1ee6a9a95be524cf80a0eb47928ac6954d9dbab677e062d594` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/KwsListener.kt` | 11 | `8ffb696aad81a538be004c47c8ecc304c7ebda3e4e1e0e3541c7b311d7e0bdf5` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/KwsState.kt` | 15 | `6847141700cc73b0699158450dba1bcd1530e5791585a6b240585880a89a3ca4` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioDeviceSelector.kt` | 27 | `91e19d153784acc0243ab4019d33dd75ba4571f5fd3c90db56fd93e439600e0a` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioFrame.kt` | 8 | `9e357e63d27a4e36cf835daed8bd1c028793a3eb2678652334de80559b19c9b6` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioInputMode.kt` | 6 | `f8f19ab7248c7cd71038b34ce402ba50f0e2d80749abe83a473165f9f332ba97` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioRecordSource.kt` | 297 | `9c19735ddeb732fe7f8400001f2fa39a807c04dcf1ebe4261271401202925443` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioSource.kt` | 15 | `bd936cf5e980004dd6e646eaeb29ba5079df72c337a77aff57218a7be1aeecb5` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/AudioSourceState.kt` | 7 | `bac0db96da7eafe6a6ec7809041d0aa2c6da2748fd00cd765cb39a55e238e840` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/SilenceDetector.kt` | 26 | `d8de28fa188704fc71d4d87acef08aebb3bac0c09976c80e830206ca63ecd412` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/audio/SwitchableAudioSource.kt` | 66 | `d3080be6a1414856f96a4fca32dcedd95961d39ea91b2afe8a066fb945703641` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/kws/AssetFileCopier.kt` | 97 | `0b1ce9055d608f8ef88f7984e13c7c8c62e5f140613d35e363f98e1e767e005d` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/kws/KwsEngine.kt` | 34 | `f3c2224c76a0f1e554178dae6980530e53a64c3cadebd84d6075c997f6051d85` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/kws/KwsEngineState.kt` | 8 | `1f4946e276aec5a990d934b3272cfc9d36f4b5d7ff016df2cbe4318f71da2369` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/kws/KwsHit.kt` | 7 | `baea28c8a31da87fc671a20868279224da9b210c064351eae7849e6bb337dda0` |
| `source/edge-kws/src/main/kotlin/com/sisp/edge/audio/kws/SherpaKwsEngine.kt` | 161 | `eac2a133f0e065b6772b2f164a2c306c8e2a8cd1608246b097374dce567caa55` |
| `source/edge-runtime/src/main/kotlin/com/sisp/edge/runtime/CoreModels.kt` | 123 | `0f980f68d2a42db64bb749d01a7b6659f40d7a1c190d5f8d6c7f11e1f6f7b9b8` |
| `source/edge-runtime/src/main/kotlin/com/sisp/edge/runtime/FallbackPolicy.kt` | 32 | `a3156bf92261bd54d55273388186b4ffffd00ba1fada00236813bf1983bcb90e` |
| `source/edge-runtime/src/main/kotlin/com/sisp/edge/runtime/SispCorePort.kt` | 48 | `b785e11c1fb73ad6c3017cfdeb873085f868623012d8c4e24b37ebe8727e4f51` |
| `source/edge-runtime/src/main/kotlin/com/sisp/edge/runtime/SispRuntimeCoordinator.kt` | 208 | `c09834bd1602dee759c6e47623eac590ccf3921f6ab94a6f88744977c32e486f` |
| `source/edge-runtime/src/main/kotlin/com/sisp/edge/runtime/SyncJournal.kt` | 59 | `76d3c822a483ed518f3912ae188765a9c3254f34ca881532cd6b37be96812b4b` |
| `source/edge-runtime/src/test/kotlin/com/sisp/edge/runtime/SispRuntimeCoordinatorTest.kt` | 175 | `29c1152c20957955492b6a9185d58ff7df491ff53091c18c375e22cd0288eb57` |
| `source/shared-contracts/src/main/kotlin/com/sisp/shared/contracts/VisionContracts.kt` | 13 | `d418a8cbee76ce6a575cd8c0c69f56af4e6639c339e4f59cd946cf9544e6089d` |
