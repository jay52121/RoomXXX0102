# Capability Matrix

| 能力 | Core 可用 | Core 不可用 | 权威性 |
|---|---|---|---|
| 相机与音频采集 | APK | APK | 输入事实 |
| 低延迟 KWS | APK | APK | 触发信号 |
| 多摄像头轨迹融合 | SISP Core | 不可用 | Core 权威 |
| 单摄像头基础跟踪 | Core 协调 | APK 冗余 | 降级临时 |
| 长期空间 Presence | SISP Core | 不可用 | Core 权威 |
| 缓存配置下空间估计 | Core 校验 | APK 冗余 | 降级临时 |
| 多模态设备决策 | SISP Core | 不可用 | Core 权威 |
| 短窗口设备指向 | Core 决策 | APK 冗余 | 降级临时 |
| 设备控制授权 | SISP Core | 默认禁止 | Core 权威 |
| 配置和策略下发 | SISP Core | 使用缓存 | Core 权威 |
| 日志与恢复对账 | SISP Core | APK 暂存 | Core 权威 |

本地冗余的目标是维持采集与基础交互连续性，不是复制完整服务端能力。
