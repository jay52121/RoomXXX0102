# SISP Core Ports

## SispCorePort

`SispCorePort` 是 APK 与权威 Core 的主边界，公开以下能力契约：

- `discover`：发现可用 Core，不暴露发现协议；
- `openSession`：建立终端会话并完成能力协商；
- `fetchConfiguration`：获取带版本号的权威配置快照；
- `evaluate`：提交结构化观测并取得权威决策；
- `reconcile`：补传离线日志并取得权威对账结果；
- `closeSession`：释放会话资源。

## TrackerServicePort

`TrackerServicePort` 是空间跟踪的专用出站端口。`ResilientTrackEngine` 只依赖该接口，因此生产实现可选用 SISP Core 内部路由、本地 IPC、gRPC 或其他传输方式。

## Intentionally Omitted Adapters

以下生产实现属于公司核心资产，本包仅保留接口：

- 服务发现与选主；
- 终端认证、会话密钥和请求签名；
- 加密传输、协议协商与序列化；
- Core 内部模型编排和多终端融合；
- 设备控制授权、幂等执行和审计；
- 服务端持久化、日志评测和运维能力。

这种边界使 APK 的运行时状态机和本地连续性能力可以独立测试，同时不耦合生产基础设施。
