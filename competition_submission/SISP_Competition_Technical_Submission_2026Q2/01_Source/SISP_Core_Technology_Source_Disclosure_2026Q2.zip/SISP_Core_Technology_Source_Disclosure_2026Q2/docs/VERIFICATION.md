# Verification Record

## Edge Runtime

验证范围：

- Core 可用时进入 `CORE_PRIMARY`；
- Core 不可用时进入 `EDGE_CONTINUITY`；
- 本地结果标记为 `EDGE_PROVISIONAL`；
- 离线观测写入顺序日志；
- Core 恢复后执行 reconcile；
- Core 确认后清理日志并回到 `CORE_ACTIVE`。

结果：3 项测试全部通过。

## Package Integrity

- 所有披露文件生成独立 SHA-256；
- ZIP 生成外部 SHA-256；
- 压缩结构执行完整性测试；
- 扫描固定 IP、URL、密钥、内部工程代号和个人路径。
