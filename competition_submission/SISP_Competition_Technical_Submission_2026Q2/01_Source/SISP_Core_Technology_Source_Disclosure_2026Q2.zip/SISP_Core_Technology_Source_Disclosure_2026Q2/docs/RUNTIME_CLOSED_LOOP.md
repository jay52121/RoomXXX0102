# Runtime Closed Loop

## Normal Operation

```mermaid
sequenceDiagram
    participant E as Android Edge
    participant C as SISP Core
    E->>C: Discover + Open Session
    C-->>E: Capabilities + Session
    E->>C: Fetch Configuration
    C-->>E: Versioned Snapshot
    loop Structured observations
        E->>C: ObservationEnvelope
        C-->>E: Authoritative Decision
    end
```

Core 正常时，APK 不在本地形成长期权威状态。所有设备动作和空间状态变更以 Core 决策为准。

## Degraded Operation

```mermaid
sequenceDiagram
    participant E as Android Edge
    participant F as Edge Continuity
    participant J as SyncJournal
    E-xSISP Core: Session / Evaluation Failed
    E->>F: Evaluate supported observation
    F-->>E: EDGE_PROVISIONAL decision
    E->>J: Append observation + config version + provisional result
```

降级能力受 `FallbackPolicy` 限制，并依赖有效的缓存配置。APK 不会把临时结果伪装成 Core 权威结果。

## Recovery

```mermaid
sequenceDiagram
    participant E as Android Edge
    participant J as SyncJournal
    participant C as SISP Core
    E->>C: Rediscover + Open Session
    E->>C: Fetch latest configuration
    E->>C: Reconcile ordered journal
    C-->>E: Ack sequence + authoritative snapshot
    E->>J: Remove acknowledged entries
    E->>E: Switch to CORE_PRIMARY
```

恢复流程把配置更新、日志确认和权威状态切换放在同一闭环中，避免服务重连后出现双重状态源。
