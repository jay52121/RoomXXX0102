# Dependencies & Integration Boundary

本披露包保留架构契约、边缘运行时和最小本地冗余源码，不携带模型权重、业务数据、第三方二进制、生产服务适配器和完整 Android 应用构建脚本。

| 模块 | 运行依赖 | 定位 |
|---|---|---|
| edge-runtime | Kotlin | Core-first 状态机、降级与恢复对账 |
| edge-kws | Android AudioRecord, Kotlin Coroutines, Sherpa-ONNX | APK 常驻低延迟能力；模型/AAR 未包含 |
| edge-fallback-pointing | Android `PointF` / `RectF`, Kotlin | Core 不可用时的短窗口冗余 |
| edge-fallback-spatial | Android graphics/log, Kotlin | 单终端空间冗余；服务适配未包含 |
| shared-contracts | Kotlin | 最小跨模块契约 |

宿主应用负责生命周期、权限、模型资产、配置缓存和可视化。基础设施层负责实现 `SispCorePort` 与 `TrackerServicePort`，并提供服务发现、认证、加密、协议协商和传输。披露源码中不存在默认服务地址。
