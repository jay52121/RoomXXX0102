# Device Pointing Algorithm Notes

## 静态目标预计算

每个设备由 `deviceId + hotspot + convex polygon` 描述。窗口开始时按图像尺寸完成像素空间转换，并预计算短边、热点半径、区域辅助半径、近场距离、后向容忍距离、穿透归一长度和裁剪距离。

## 单帧评分

单帧评分由热点路径与区域路径组成：

```text
geometricScore = hotspotWeight × hotspotScore
               + polygonWeight × polygonScore

frameScore = frameQuality × geometricScore
```

热点路径强调指向精度；区域路径利用射线到多边形距离和内部穿透长度提升稳定性。近场支持因子会平滑调节两条路径的权重与射线裁剪距离。

## 时序聚合

窗口后段帧获得更高权重，以适应用户从抬手到稳定指向的自然动作过程。最终分数组合加权平均、时序峰值与领先比例，同时要求最低命中比例和候选间领先倍率。

```text
finalScore = 0.70 × weightedAverage
           + 0.15 × temporalPeak
           + 0.15 × weightedLeadRatio
```

动态最终阈值依据窗口平均帧质量调整，但受绝对最低阈值约束。这样既避免低质量窗口过度拒绝，也防止阈值无限下探。
