# SISP Architecture

## 权威模型

SISP Core 是房间配置、设备配置、空间状态和设备决策的权威来源。APK 不维护与 Core 并列的第二套长期状态；离线期间产生的本地结果统一标记为 `EDGE_PROVISIONAL`，恢复后以 Core 对账结果为准。

## 分层

| 层级 | 主要职责 | 披露组件 |
|---|---|---|
| Edge I/O | 相机、音频、用户交互和设备动作执行 | `AudioSource`, shared contracts |
| Runtime Coordination | 会话、运行模式、配置版本、降级和恢复 | `SispRuntimeCoordinator` |
| Core Port | 服务发现、配置、评估和对账契约 | `SispCorePort`, `TrackerServicePort` |
| Edge Continuity | Core 不可用时的受限本地冗余 | pointing/spatial fallback modules |
| SISP Core | 多终端融合、权威状态、设备决策与控制 | 生产实现未披露 |

## 架构不变量

1. Core 返回的决策始终标记为 `SISP_CORE`，优先级高于任何本地结果。
2. 本地冗余结果必须标记为 `EDGE_PROVISIONAL`，不得直接成为长期权威状态。
3. 每条离线事件绑定所使用的配置版本，并以单调递增序号写入 `SyncJournal`。
4. Core 恢复后先刷新配置，再提交离线日志并执行对账。
5. 日志只在 Core 明确确认序号后删除，避免静默丢失事件。
6. 服务地址、认证、加密和传输协议不进入算法模块，由基础设施适配器运行时注入。

## Edge Continuity Boundary

APK 常驻 KWS 是出于交互延迟和隐私考虑。单摄像头跟踪、短窗口设备指向和缓存空间配置仅在 Core 不可用时承担有限连续性；跨终端身份、长期 Presence、冲突解决、策略下发和设备控制授权仍属于 Core。

## Failure Isolation

- Core 评估失败触发运行模式降级，不阻塞采集和 UI。
- 本地冗余只处理 `FallbackPolicy` 允许的观测类型。
- 缓存配置超过有效期后停止依赖空间配置的本地决策。
- 离线日志有容量上限，采用顺序确认语义。
- 跟踪服务故障进入冷却期，并回退单终端本地跟踪。
- 不确定的设备指向输出 `UNDETERMINED`，不强制猜测。
