# Build & Verification

`edge-runtime` 不依赖 Android SDK，可作为 Core-first 状态闭环的独立验证入口。

环境要求：

- JDK 17+
- Gradle 8.12+

执行：

```bash
gradle :edge-runtime:test
```

测试覆盖 Core 正常连接、Core 不可用时的边缘连续性，以及 Core 恢复后的日志补传与权威状态对账。

其余模块属于 Android 边缘冗余源码披露，需要宿主应用、Android SDK、模型资产或未披露的基础设施适配器，不在本包中提供独立产品构建。
