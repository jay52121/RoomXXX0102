# SISP Core / Edge Continuity Architecture

> Spatial Intelligence Service Platform · Limited Source Disclosure · 2026 Q2

SISP 是以 **SISP Core 为权威计算与状态中心**、以 Android APK 为轻量边缘终端的空间智能平台。Core 负责配置、跨终端感知融合、长期空间状态、设备决策和控制；APK 负责采集、低延迟交互、结果呈现以及 Core 不可用时的最小本地连续性保障。

本包披露的是早期 Demo 中的 **SISP Edge Continuity Runtime**、Core 接口契约和部分本地冗余参考实现。生产级 SISP Core、服务发现、认证、传输适配、模型资产与核心策略未包含。

## System Topology

```mermaid
flowchart LR
    subgraph EDGE[Android Edge Terminal]
        CAP[Camera / Audio Capture]
        KWS[Low-latency KWS]
        RT[SispRuntimeCoordinator]
        CACHE[Versioned Config Cache]
        FB[Restricted Local Fallback]
        UI[Visualization / Action]
        CAP --> KWS
        CAP --> RT
        KWS --> RT
        RT --> UI
        CACHE --> FB
        FB --> RT
    end

    subgraph CORE[SISP Core - Authoritative]
        DISC[Service Discovery & Session]
        CFG[Configuration Authority]
        FUSION[Multi-terminal Fusion]
        STATE[Spatial State Engine]
        DECISION[Device Decision & Control]
        RECON[Journal Reconciliation]
        DISC --> CFG --> FUSION --> STATE --> DECISION
        RECON --> STATE
    end

    RT <-->|SispCorePort| DISC
    RT -->|Structured Observations| FUSION
    DECISION -->|Authoritative Decisions| RT
    RT -. Core unavailable .-> FB
    RT -. Recovery journal .-> RECON
```

## Runtime Closed Loop

| 阶段 | 执行模式 | 行为 |
|---|---|---|
| Core 可用 | `CORE_PRIMARY` | 上传结构化观测，由 Core 返回权威配置、空间状态和设备决策 |
| Core 不可用 | `EDGE_CONTINUITY` | 使用缓存配置执行受限的单终端本地判断，输出标记为 `EDGE_PROVISIONAL` |
| Core 恢复 | `RECOVERING` | 补传顺序日志、刷新配置、接受权威快照并完成状态对账 |

`SispRuntimeCoordinator` 实际实现 `DISCOVERING → CONNECTING → CORE_ACTIVE → EDGE_DEGRADED → RECOVERING → CORE_ACTIVE` 状态闭环，而不是只提供概念接口。

## Source Modules

```text
source/
├── edge-runtime/             # Core-first 状态机、能力协商、降级策略、日志与恢复对账
├── edge-kws/                 # APK 常驻的低延迟流式关键词识别
├── edge-fallback-pointing/   # Core 不可用时的短窗口设备指向参考实现
├── edge-fallback-spatial/    # 单摄像头跟踪与空间状态冗余实现
└── shared-contracts/         # 跨模块视觉数据契约
```

## Core-side Responsibilities

- 房间、设备、策略和算法版本的唯一真相源；
- 多终端、多摄像头轨迹融合与身份连续性；
- 长期 Presence 状态和空间事件编排；
- 语音、人体、手势、设备上下文的多模态融合；
- 设备指向判定、动作授权、执行审计与状态回写；
- 边缘事件日志接收、冲突解决和恢复对账。

## Edge Continuity Responsibilities

- 相机、视频音轨和麦克风采集；
- 低延迟 KWS 与短时交互窗口；
- Core 会话、能力和配置版本管理；
- 断线期间的有限本地推断与顺序事件日志；
- Core 恢复后的补传、配置刷新和权威状态切换；
- 画面绘制、用户提示和设备动作执行。

## Disclosed Fallback Algorithms

设备指向冗余链预计算设备热点和凸四边形尺度，融合射线前向性、后向软衰减、区域接近度、多边形穿透、帧质量和后置时间权重；窗口结束时以动态阈值、命中比例和领先倍率约束结果。

空间冗余链提供单摄像头跟踪接口、在途请求控制、失败冷却、本地降级和房间迁移估计。上述实现只用于 Core 不可用期间维持基础连续性，不替代生产 Core 的跨终端融合与权威状态管理。

## Verification Assets

- 指向几何与窗口判定回归测试；
- Core 正常进入权威模式测试；
- Core 失联进入本地连续性并记录日志测试；
- Core 恢复后完成日志补传和权威对账测试；
- 逐文件 SHA-256 清单与压缩包外部校验。

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Runtime Closed Loop](docs/RUNTIME_CLOSED_LOOP.md)
- [Capability Matrix](docs/CAPABILITY_MATRIX.md)
- [Core Ports](docs/CORE_PORTS.md)
- [Fallback Algorithm Notes](docs/ALGORITHM_NOTES.md)
- [Dependencies](docs/DEPENDENCIES.md)
- [Disclosure Scope](docs/DISCLOSURE_SCOPE.md)
- [Build & Verification](BUILDING.md)
- [Verification Record](docs/VERIFICATION.md)

## Intellectual Property & Disclosure

本包属于有限技术披露材料，不是现行产品完整仓库。早期 Demo、本地冗余代码与现行 SISP Core 的披露边界见 [DISCLOSURE_SCOPE.md](docs/DISCLOSURE_SCOPE.md) 和 [LICENSE.txt](LICENSE.txt)。
