# Third-party Components

本源码包中的接口或适配代码可能与以下组件协同工作，但不包含其二进制、模型或源码：

- Android SDK / AndroidX
- Kotlin Coroutines
- Sherpa-ONNX
- JUnit

相关组件的使用应分别遵循其官方许可证。赛事接收方不因取得本包而获得上述第三方资产的额外授权。
